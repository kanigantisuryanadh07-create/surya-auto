# Surya Automations — Full-stack starter

A responsive showroom/automotive concept based on the screenshots supplied in chat.

## Run locally
1. Install Node.js 18 or newer.
2. In this folder run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

## Frontend
- `public/index.html` — page structure and content
- `public/styles.css` — responsive styling
- `public/app.js` — mobile navigation, API loading and enquiry form

## Backend
- `server.js` — Express server and JSON APIs
- `GET /api/health` — service health
- `GET /api/vehicles` — collection data
- `POST /api/inquiries` — validates and saves enquiries to `data/inquiries.json`
- `GET /api/admin/inquiries` — protected admin endpoint

## Admin endpoint
Set an environment variable before starting the server:
- macOS/Linux: `ADMIN_KEY="your-long-secret" npm start`
- Windows PowerShell: `$env:ADMIN_KEY="your-long-secret"; npm start`

Then send `GET /api/admin/inquiries` with header `x-admin-key: your-long-secret`.
Do not put the admin key in frontend JavaScript or commit it to GitHub.

## Before publishing
- Replace the sample Unsplash image URLs with licensed images you own or have permission to use.
- Replace sample vehicle copy and categories with the actual Surya Auto inventory.
- Add a production database (PostgreSQL/MongoDB), HTTPS, rate limiting, spam protection and proper admin login before public production use.
- This is a clean recreation from screenshots, not the original Emergent source code or database.
