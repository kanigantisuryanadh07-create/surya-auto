const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const INQUIRIES_FILE = path.join(DATA_DIR, "inquiries.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(INQUIRIES_FILE)) fs.writeFileSync(INQUIRIES_FILE, "[]");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const vehicles = [
  { id: 1, name: "Classic Roadster", category: "Cars", year: "1970s", description: "A timeless design with unmistakable character.", status: "Featured" },
  { id: 2, name: "Heritage Scooter", category: "Scooters", year: "1960s", description: "Iconic city style, made for memorable journeys.", status: "Featured" },
  { id: 3, name: "Vintage Motorcycle", category: "Motorcycles", year: "1980s", description: "A classic silhouette with a story to tell.", status: "Collection" }
];

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Surya Automations API" }));
app.get("/api/vehicles", (_req, res) => res.json(vehicles));

app.post("/api/inquiries", (req, res) => {
  const { name, email, phone, interest, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ error: "Name, email and message are required." });
  }
  const inquiries = JSON.parse(fs.readFileSync(INQUIRIES_FILE, "utf8"));
  const inquiry = {
    id: Date.now().toString(),
    name: String(name).trim(),
    email: String(email).trim(),
    phone: String(phone || "").trim(),
    interest: String(interest || "General enquiry").trim(),
    message: String(message).trim(),
    createdAt: new Date().toISOString()
  };
  inquiries.unshift(inquiry);
  fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(inquiries, null, 2));
  res.status(201).json({ success: true, message: "Your enquiry has been received.", inquiryId: inquiry.id });
});

// Simple protected-by-environment-key admin endpoint.
// Set ADMIN_KEY before deployment; never expose it in frontend code.
app.get("/api/admin/inquiries", (req, res) => {
  const expected = process.env.ADMIN_KEY;
  if (!expected || req.headers["x-admin-key"] !== expected) {
    return res.status(401).json({ error: "Unauthorized. Configure ADMIN_KEY and send it in x-admin-key." });
  }
  res.json(JSON.parse(fs.readFileSync(INQUIRIES_FILE, "utf8")));
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Surya Automations running at http://localhost:${PORT}`));
