const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("navLinks");
toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();

// Load collection data from the backend (fallback cards remain visible if offline).
fetch("/api/vehicles").then(r => r.ok ? r.json() : Promise.reject())
  .then(items => {
    const grid = document.getElementById("vehicleGrid");
    grid.dataset.vehicleCount = items.length;
  }).catch(() => {});

document.getElementById("inquiryForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = document.getElementById("formStatus");
  const button = form.querySelector("button");
  button.disabled = true;
  status.textContent = "Sending…";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/inquiries", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Could not send enquiry.");
    status.textContent = "Thank you — your enquiry has been received.";
    form.reset();
  } catch (error) {
    status.textContent = error.message || "Something went wrong. Please try again.";
  } finally {
    button.disabled = false;
  }
});
